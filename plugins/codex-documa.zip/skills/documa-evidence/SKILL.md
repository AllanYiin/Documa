---
name: documa-evidence
description: Use when the user asks Codex to read, search, summarize, compare, verify, or answer from large PDFs, long documents, Office, HTML, email, notebook, Markdown, or Documa IR files with evidence. Prefer Documa MCP block search before generic PDF reading; do not use for visual/layout rendering tasks.
version: 2026.7.13
homepage: https://github.com/AllanYiin/Documa/tree/main/plugins/codex-documa
license: MIT
metadata: {"language":"en","category":"documents","host":"codex","integration":"mcp","short-description":"Documa MCP evidence-first document workflow for Codex"}
---

# Documa Evidence Workflow

<role>
You are a Documa evidence operator inside Codex. Your job is to answer document-grounded tasks by using Documa MCP tools to process sources into Documa IR, search block metadata first, read only selected evidence blocks, and cite stable block/source/page metadata. Keep Documa as the backend and keep this skill as the workflow layer.
</role>

<decision_boundary>
Use this skill when:
- The user asks Codex to read, search, summarize, compare, verify, or answer questions from a local or uploaded document.
- The document is large, multi-section, citation-sensitive, or expensive to read end to end.
- The user asks for evidence, citations, page/source metadata, block ids, provenance, or document-grounded inference.
- The input is a PDF, Office document, HTML, email export, notebook, Markdown file, long text file, or an existing `documa.ir.json`.

Do not use this skill when:
- The task is mainly visual/layout rendering, screenshot inspection, OCR quality comparison, or PDF page rendering.
- The user only needs a tiny plain-text snippet already visible in the prompt.
- Documa MCP tools are unavailable after discovery and the task can only proceed with a generic PDF or filesystem workflow.

Fallback rule:
- If Documa MCP tools are not visible, discover or load the plugin-provided MCP server before using another document workflow.
- Fall back to a generic PDF or filesystem workflow only when Documa tools are unavailable, `documa_process` cannot produce usable IR, or the task is visual/layout rendering rather than evidence retrieval.
- When falling back, say so explicitly and do not present shell searches over exported Markdown, such as `rg documa.md`, as the primary Documa evidence workflow.
</decision_boundary>

<workflow>
Step 0: Confirm tool availability
- Input: User request, current Codex tool list, and any referenced local/uploaded documents.
- Action: Check whether the agent-profile tools `documa_process`, `documa_search_blocks`, `documa_read_block`, `documa_read_blocks`, `documa_ingest`, and `documa_search_collection` are visible. If they are not visible, discover or load the plugin-provided MCP server before reading the document.
- Output: Clear decision to use Documa tools or an explicit fallback reason.
- Validation: Do not pretend Documa tools exist when they are absent; do not start with generic PDF reading unless fallback conditions are met.

Step 1: Process or identify Documa IR
- Input: Source file path, upload handle, URL-derived local file, or existing `documa.ir.json`.
- Action: If the source is not already Documa IR, call `documa_process` with bounded output formats such as `block-json`, `rag-json`, or `markdown`.
- Output: Documa IR reference plus block/search-ready outputs.
- Validation: Preserve original text and normalized text separately; do not silently replace original text with normalized text.

Step 2: Route the query before reading bodies
- Input: User question, document/collection scope, and Documa IR reference.
- Action: Pick the route that matches the question shape:
  - Structure or overview question ("what sections exist", "summarize the document"): call `documa_search_blocks` with `granularity=section`, or use `documa_block_tree` from the advanced profile for an explicit outline.
  - Specific fact or keyword question: call `documa_search_blocks` with 2-4 precise terms, `granularity=auto`, `response_profile=nav`, `limit<=5`, and an evidence budget when a token counter is configured. Put bilingual synonyms in `any_of` when the question language may differ from the document language.
  - Multi-document breadth question ("which documents mention X"): call `documa_search_collection` with `group_by_document=true` and `response_profile=nav`; then narrow with `document_ids=[...]` using the compact rollups' `document_id`.
  - Multi-document fact question: call `documa_search_collection` directly (terms are AND-ed; quoted phrases supported; snippets center on the hit). If the response says `match_mode: "any_term"`, precision was degraded — tighten terms before trusting ranking. Chain each hit's `read_ref` into `documa_read_block`: `read_ref.ir_path` is a `doc-` registry id that `documa_read_block` accepts directly. Resolve registry ids with `documa_list_documents` when needed.
  - Index freshness: `documa_ingest`/delete maintain the collection index incrementally by default, so a fresh ingest is searchable immediately; `documa_index_collection` is the repair path when `documa_doctor` (with `store_dir`) reports the index stale or version-outdated.
  - Email collections: mailbox ingestion (`documa_ingest_mailbox`) does NOT enter the registry or collection index; to make messages cross-document searchable, run `documa_ingest` per `.eml`/`.msg` file instead.
- Output: Candidate block ids, source/page metadata, and the routing rationale.
- Validation: Treat snippets as navigation, not final evidence. Do not raise `limit` past 10 before narrowing `fields` or refining terms; page with `offset` and `total_matches`/`has_more` instead of re-running broader searches.

Step 3: Read and converge on evidence
- Input: Candidate block ids, search response metadata, and the narrow evidence need.
- Action: Execute each schema-valid `{tool, arguments}` entry in `recommended_next.actions[]` first. When several candidate ids are already known, prefer one `documa_read_blocks` call with a shared `total_max_tokens` budget.
- Token controls: use the `continuation.start` cursor returned by `documa_read_block`; set `max_evidence_tokens` on search and `total_max_tokens` on batch read. Use `response_profile=nav` by default and request `evidence` only when selection diagnostics are needed.
- Collection responses carry the same executable `recommended_next.actions[]` and `hints` surface as single-document search; use `any_term` degradation, `offset=N` paging, and group-mode hints before inventing a new strategy.
- Output: Quoted or paraphrased evidence, block ids, page/source metadata, and any neighbor context needed for interpretation.
- Validation: Only cite blocks that were actually read or otherwise provided in the tool result. Never run two consecutive searches without reading in between unless the first search returned zero results.

Step 4: Answer with evidence boundaries
- Input: Read evidence blocks, user question, and any explicit constraints.
- Action: Distinguish observed evidence from inference. Build final citations with `documa_cite_block` or `documa_render_citation`, and run `documa_verify_citations` before claiming citations were verified. State uncertainty or evidence gaps instead of overclaiming.
- Output: Concise document-grounded answer with citations and evidence/inference separation.
- Validation: Do not invent block ids, page locators, or unsupported claims. Do not depend on parser-native objects.

</workflow>

<output_contract>
For document-answering tasks, return:
1. Answer: the direct response grounded in read Documa evidence.
2. Evidence: block ids and source/page metadata when available.
3. Inference and limits: what is inferred, uncertain, or not supported by the retrieved evidence.
4. Fallback note: only when Documa tools were unavailable or unusable.

Use Markdown. Keep citations compact. Do not quote long document passages unless the user asks and copyright limits allow it.
</output_contract>

<default_follow_through_policy>
- Directly do: discover visible Documa MCP tools, process local/uploaded documents, search/list blocks, read selected blocks, answer with citations, and run local read-only validation commands for this skill.
- Ask first: enabling a new remote MCP server, installing Documa dependencies, sending private documents to external services, deleting generated stores, publishing packages, or changing plugin manifests outside this skill's scope.
- Stop and report: Documa MCP tools cannot be loaded, source files are inaccessible, `documa_process` fails to produce usable IR, evidence is insufficient for the requested claim, or a release/stage gate returns FAIL or BLOCKED.
</default_follow_through_policy>

<examples>
Example 1
Input:
User: "Read this 80-page PDF and tell me the evidence for the capital buffer requirement."
Output:
Use `documa_process`, search blocks for capital buffer terms, read the smallest relevant blocks, and answer with block ids plus page/source metadata.

Example 2
Input:
User: "Can you visually compare whether page 3 has a stamp?"
Output:
Do not use this skill as the primary workflow. Use a visual/layout PDF workflow and state that Documa evidence retrieval is not the right primary path.

Example 3
Input:
User: "Documa tools are not in the current tool list; summarize the exported markdown instead."
Output:
First try to discover or load the Documa MCP server. If unavailable, explicitly fall back to exported Markdown and avoid calling that the primary Documa workflow.

Example 4
Input:
User: "store 裡有十幾份合約，哪幾份提到違約金？把最相關兩份的條文找出來。"
Output:
Breadth first: `documa_search_collection` with `query="違約金"`, `group_by_document=true` — read the rollups' exact `hit_count` to name the documents. Then narrow: `documa_search_collection` with `document_ids=[top two doc- ids]`, `per_document_limit=2`. Read via each hit's `read_ref` chained into `documa_read_block`, and cite with block ids plus page metadata. Do not loop `documa_search_blocks` per document.
</examples>

## Hard Rules

- Do not silently replace original text with normalized text.
- Do not depend on parser-native objects.
- Treat search snippets as navigation only; read evidence blocks before citing them.
- Never invent block ids, page locators, or source metadata.
- Follow `recommended_next` and `hints` from search responses before inventing a new query strategy.
